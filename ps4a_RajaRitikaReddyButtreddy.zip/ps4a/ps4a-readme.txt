/**********************************************************************
 *  readme.txt template
 *  PS4a
 *  Synthesizing a Plucked String Sound: 
 *  CircularBuffer implementation with unit tests and exceptions 
 **********************************************************************/
Name : Buttreddy Raja Ritika Reddy (01987338)
Email : RajaRitikaReddy_Buttreddy@student.uml.edu
Hours to complete assignment: 2-3 hours  

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
**********************************************************************/

The implemetaion of queue. Learned about cpplint and also this assignment
is solved using a circular buffer to generate a plucked string and it is 
also tested using unit and boost tests.
Key elements such as capcity, enqueue and dequeue are used to implement
the queue.A deeper understanding of space and time complexity.

/**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.
 **********************************************************************/
The main datastructure used is a "QUEUE". First in first out mechanism
is implemented where the first entered element is removed first unlike 
stack. The use of vectors and also I implemented lamda expression in the 
code.

/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Include code excerpts.
 **********************************************************************/
The data is kept in an array with two pointers to the front and rear of 
the queue, which only expand until the pointer meets capacity and then 
returns to zero. The function circularbuffer is used which implements 
multiple API'S such as enqueue() etc.
I also used lamda expression which was a convenient way of defining an anonymous 
function object right at the location where it's invoked as an argument to a function.

Lamda Expression  :  auto lamda = [](int len) 
                {
                  return len == 0;
                };

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
Yes I completed all tasks given Successfully.
All the functions such as size(), isEmpty() work perfectly as I united 
tested all of them and they passed successfully.

/**********************************************************************
 *  Does your CircularBuffer implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/
Yes, the circular buffer implementation was successfully tested when I ran it.
This is the output generated when runned :
Running 7 test cases...

*** No errors detected

/**********************************************************************
 *  Explain the time and space performance of your RingBuffer
 *	implementation
 **********************************************************************/
time: O(1).
space: All methods are both O(1) except that constructor (Constructor is O(n))

/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/
None. Except for the explanation in the class and thepdf provided.


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
None


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
 None 
