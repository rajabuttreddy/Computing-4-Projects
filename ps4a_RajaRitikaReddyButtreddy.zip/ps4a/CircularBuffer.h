/*
 * Copyright 2021 Buttreddy Raja Ritika Reddy (01987338)
 * All rights reserved.
 */
#ifndef CIRCULARBUFFER_H_
#define CIRCULARBUFFER_H_
#include <stdint.h>
#include <vector>
#include <exception>
#include <stdexcept>
#include <iostream>

class CircularBuffer {
 public:
    explicit CircularBuffer(int Max_size);

    void prettyPrint();
    bool isEmpty();
    bool isFull();
    void enqueue(int16_t x);
    int16_t dequeue();
    int16_t peek();
    int size();


 private:
        std::vector<int16_t> buffer;
        int len;
        int Max_size;
        int head;
        int tail;
};
#endif  
