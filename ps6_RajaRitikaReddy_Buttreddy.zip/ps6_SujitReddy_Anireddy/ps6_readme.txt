/**********************************************************************
 *  readme.txt template                                                   
 *  Random Writer 
 **********************************************************************/

Name: Buttreddy Raja Ritika Reddy

Hours to complete assignment: 8-10 Hours 
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
In this assignment we examine an input text for transitions between k-grams
and the letter that follows it and create a textual probabilistic model with
any possible text. I finished all the tasks given in this assignment and the 
code generates random text for a given input (K-series) which satisifies the 
logic mentioned in the PDF.
  /**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.
 **********************************************************************/
I used the started code which was given in the pdf. The use of constructors,
datatypes, strings and other Cpp concepts are used in this assignment.
/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Include code excerpts.
 **********************************************************************/
I passd all of the unit tests, therefore the majority of my code should function.
In addition, when I run my main, I receive pseudo random text 
that, as far as I know, follows the logic mentioned in the class.
code excerpts :
for (unsigned int a = 0; a < _alphabet.length(); a++) {
    test_freq =  static_cast<double>(freq(kgram, _alphabet[a])) / kgram_freq;
    if (random_num < test_freq + last_values && test_freq != 0) {
      return _alphabet[a];
/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
Yes I completed the assignmnet. I checked it my passing all the usit tests.
And as mentioned in the pdf I passed using the input17.txt file and this is the
output I got :
ORIGINAL INPUT TEXT BELOW THIS LINE.

 gagggagagg

FINAL OUTPUT TEXT BELOW THIS LINE.

 gagaa gaa 

 So I think everything works perfectly.
/**********************************************************************
 *  Does your implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/
Yes it passes the unit tests. 
I know because NO ERRORS DETECTED shows up in the terminal.
 /**********************************************************************
 *  Describe where you used exceptions. 
 *  Provide files and lines of the code.
 ***********************************************************************/
In test.cpp file exceptions are used.
 /**********************************************************************
 *  Describe where you used lambda expression if any
 *  Provide files and lines of the code.
 ***********************************************************************/
I did not use lambda expression in my code.
/**********************************************************************
 *  Did you implemented program for extra poits? If yes, describe your 
 *  If yes, describe your implementation.
 ***********************************************************************/
NO.
/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/
Irfan Mohammad - TA for Comp 1,2,3,4.
/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
None.
/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
None. 