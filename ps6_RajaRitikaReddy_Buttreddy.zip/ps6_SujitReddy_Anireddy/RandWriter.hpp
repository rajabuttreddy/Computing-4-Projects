/*
 * Copyright 2021 Buttreddy Raja Ritika Reddy
 * All rights reserved.
 * MIT Licensed - see http://opensource.org/licenses/MIT for details.
 *
 */
#ifndef RandWriter_HPP
#define RandWriter_HPP
#include <algorithm>
#include <iostream>
#include <map>
#include <string>
#include <stdexcept>
class RandWriter {
 public:
  RandWriter(std::string text, int k);
  int order();
  int freq(std::string kgram);
  int freq(std::string kgram, char c);
  char randk(std::string kgram);
  std::string gen(std::string kgram, int T);
  friend std::ostream& operator<< (std::ostream &out, RandWriter &mm);
 private:
  int _order;
  std::map <std::string, int> _kgrams;
  std::string _alphabet;
};
#endif
