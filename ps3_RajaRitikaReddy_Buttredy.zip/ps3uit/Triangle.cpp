#include "Triangle.h"

Triangle::Triangle(sf::Vector2f p, sf::Vector2f q, sf::Vector2f r) {
    p1 = p;
    p2 = q;
    p3 = r;

    bottom = NULL;
    left = NULL;
    right = NULL;
}

void Triangle::draw(sf::RenderTarget &target, sf::RenderStates states) const {
    sf::Vertex line[] = {
        sf::Vertex(p1, sf::Color(3,253,53)),
        sf::Vertex(p2, sf::Color(3,253,53)),
    };
    
    target.draw(line, 2, sf::Lines);

    line[0] = sf::Vertex(p2, sf::Color(3,253,53));
    line[1] = sf::Vertex(p3, sf::Color(3,253,53));
    target.draw(line, 2, sf::Lines);

    line[0] = sf::Vertex(p1, sf::Color(3,253,53));
    line[1] = sf::Vertex(p3, sf::Color(3,253,53));
    target.draw(line, 2, sf::Lines);
}
