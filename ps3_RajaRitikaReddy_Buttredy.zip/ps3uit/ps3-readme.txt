/**********************************************************************
 *  ps3-readme 
 *  Recursive Graphics (Triangle Fractal)                       
 **********************************************************************/

Your name: Buttreddy Raja Ritika Reddy  ( UML ID - 01987338 )

Hours to complete assignment: 7-8 hours 

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 
In this assignment we write a program that plots a Triangle Fractal (Sierpinski triangle).
The use of recursive functions and data structures are implemented,
also some math to calculate the coordinates for the triangles and then
used "fTree" to draw the triangles.

 **********************************************************************/


/**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.

 Basic OO concepts, classes, linkedlists and many other base concepts are used.
 The use of linkedlist os very crucial as the dependency of the triangles are on it
 to iterate 3 times and recursivly repeat it and so on...
 **********************************************************************/



/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Include code excerpts.

I implemented the colour green with the rgb vlaues (3,253,53).
 **********************************************************************/



 /**********************************************************************
 *  Briefly explain what you learned in the assignment.

The use of pythagoras theorem and resursive functions. How to implement
recursion in sfml and a better understanding of pointers.
 **********************************************************************/



/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.

My friend helped me a little with the logic/math for the triangle, apart
from that the pdf provided.
 **********************************************************************/


/**********************************************************************
 *  Describe any serious problems you encountered.  
 *  If you didn't complete any part of any assignment, 
 *  the things that you didn't do, or didn't get working.

Figuring out on how to implement the logic into actual code was the 
toughest challange,had to spend so much time on it. 
Also I tried doing the animation part but did not work out.
 **********************************************************************/


/**********************************************************************
 *  List any other comments here.

NO comments.                                  
 **********************************************************************/

