  
  /*
*  Computing IV - Assignment 1 - PS0
*  Instructor: Prof. Yelena Rykalova
*  
*  Due Date: 13th September 2021
*
*  Student : Buttreddy Raja Ritika Reddy (UML ID 01987338)
*
*  About : This program displays on how to create a sprite and add texture using basic SFML concepts.
           The code also includes features like movement (using keytrokes) .
           
           Additional Features : ColourMode - The background changes colours when "A" is pressed and turns off when "B" is pressed.       
*/


// declaring
#include <SFML/Graphics.hpp>
class sprite {
    private:
    float x, y, velocity; 
    int screen_width, screen_height;
    public:
    float getPosX();
    float getPosY();
    void setPosX(float);
    void setPosY(float);
    void update();
    sprite(float, float, int, int, int);
};

int main()
{
    // max screen height
    int max_height = 768, max_width = 1024;
    int q = 0, p = 0;
    bool ColourMode = false;

    // creating a window
    sf::RenderWindow window(sf::VideoMode(max_width, max_height), "Assignment 1 PSO");
    window.setFramerateLimit(60);
    
    // creating a texture
    sf::Texture texture;
    if (!texture.loadFromFile("sprite.png"))
        return EXIT_FAILURE;
        
    // creating a sprite from the texture
    sf::Sprite sprite(texture);
    sprite.setPosition(100.f, 100.f);
  
    //creating arectangle for colour mode
    sf::RectangleShape bcg(sf::Vector2f(max_width, max_height));
    bcg.setPosition(0, 0);

     // Logic
    while (window.isOpen()){
        sf::Event event;
        while (window.pollEvent(event)){
            if (event.type == sf::Event::Closed)
                window.close();
        }
        
        // Following Keystrokes 
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)){
            if(!(sprite.getPosition().x <= 0))
            sprite.move(sf::Vector2f(-10.f, 0.f));
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)){
            if(!(sprite.getPosition().x >= (max_width-sprite.getGlobalBounds().width)))
            sprite.move(sf::Vector2f(10.f, 0.f));
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
             if(!(sprite.getPosition().y <= 0))
            sprite.move(sf::Vector2f(0.f, -10.f));
            
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)){
            if(!(sprite.getPosition().y >= (max_height-sprite.getGlobalBounds().height)))
            sprite.move(sf::Vector2f(0.f, 10.f));
        }
           if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
            ColourMode = true;
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::B))
            ColourMode = false;

        // Colours Switch
        window.clear();
        if (ColourMode) {
            if (p > 254) p = 0;
            if (q > 254) q = 0;
           bcg.setFillColor(sf::Color(p,q,q));
            p += 10;
            q++;
            window.draw(bcg);
        }
        
        window.draw(sprite);
        window.display();
    }
    return 0;
}
