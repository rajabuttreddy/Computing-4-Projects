/*
 * Copyright 2021 Buttreddy Raja Ritika Reddy
 * All rights reserved.
 */
#include "StringSound.h"
#include <math.h>
#include <random>
#define Samprate 44100
#define DecayFac 0.996
#define PI 3.14159265358979323846

StringSound::StringSound(double frequency) {
    blen = ceil(Samprate/frequency);
    buffer = new CircularBuffer(blen);
    for (int i = 0; i < blen; i++)
        buffer -> enqueue(0);
    _time = 0;
}
void StringSound::pluck() {
    buffer -> empty();
    int16_t val = 0;
    for (int i = 1; i <= blen; i++) {
        val = rand();
        buffer->enqueue(val);
    }
}
void StringSound::tic() {
    int16_t val = buffer -> dequeue();
    int16_t ns = (0.1 * val + 0.9 * buffer -> peek()) / 2 * DecayFac;
    // drums sound
    buffer -> enqueue(int16_t(ns));
    _time++;
}
int StringSound::time() {
    return _time;
}

sf::Int16 StringSound::sample() {
    return buffer -> peek();
}
StringSound::~StringSound() {}
