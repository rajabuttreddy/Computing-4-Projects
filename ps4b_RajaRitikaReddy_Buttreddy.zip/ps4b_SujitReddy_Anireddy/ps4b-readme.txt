/**********************************************************************
 * PS4b: StringSound implementation and SFML audio output 
 **********************************************************************/

Name: Buttreddy Raja Ritika Reddy (01987338)
Email : RajaRitikaReddy_Buttreddy@student.uml.edu
Hours to complete assignment : 5~6 hours easily 

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
Yes 
I completed all the taskes given in the assignment Successfully.
Everything is working which was mentioned in the PDF. I executed the 
KSGuitarSim.cpp file and it works perfectly and all the keystroked are 
responding to the program which is a clear success with the project.
/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  
 **********************************************************************/
Yes I impelemented a differnt version of sound (drums) instead of guitar,
which pretty much work fine.
I used this formuale - int16_t ns = (0.1 * val + 0.9 * buffer -> peek()) / 2 * DecayFac;
/**********************************************************************
 *  Did you implement exceptions to check your StringSound 
 *	implementation?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/
Yes I implemented exception handling in CircularBuffer.cpp file.
I passed the exceptions through a condition ( try, throw, catch) 
and if it passes then its further allowed in the code or else terminated or 
a comment is printed.
Code snippets : throw 
           std::runtime_error("sf::SoundBuffer: failed");
/**********************************************************************
 *  Did you implement lambda expression?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/
Yes the implemetation of lamda expression is also used. 
It was a convenient way of defining an anonymous function object right at 
the location where it's invoked as an argument to a function.
/**********************************************************************
 *  Did your code pass cpplint?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/
Yes it passed cpplint.
I passed the code through the cpplint test and there were no issues.
/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.
 **********************************************************************/
I took help from a tutor - Irfan Mohammad (Tutor for Comp 1,2,3,4).
He expalied me many things in this assignment.
/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
There were lot of sementation faults and errors while working with the 
intial code given but after spending soem time I figured it out.
Overall it was an challenging assignment ! 
/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
 None 