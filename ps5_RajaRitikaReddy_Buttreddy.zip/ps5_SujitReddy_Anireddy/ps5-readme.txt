/**********************************************************************
 *  readme 
 *  DNA Sequence Alignment
 **********************************************************************/

Name: Buttreddy Raja Ritika Reddy (01987338)

Hours to complete assignment: 10 Hours 

/**********************************************************************
 * Explain which approach you decided to use when implementing
 * (either recursive with memoization, recursive without memoization,
 * dynamic programming or Hirschberg’s algorithm). Also describe why
 * you chose this approach and what its pros and cons are.
 **********************************************************************/
I used this logic to find the alignment :
Starting from opt[0][0], there are four situations:
	1. opt[i][j] == opt[i+1][j+1] and x[i] == y[j]， skip
	2. opt[i][j] == opt[i+1][j+1] and x[i] != y[j],  modified
	3. opt[i][j] == opt[i+1][j]+2,  x insert a gap
	4. opt[i][j] == opt[i][j+1]+2,  y insert a gap
	Until opt[M][N] ceases.

I chose this approach as it was the most effective way I could think off 
to solve this problem from all the above approaches.
/**********************************************************************
 * Does your code work correctly with the endgaps7.txt test file? 
 * 
 * This example should require you to insert a gap at the beginning
 * of the Y string and the end of the X string.
 **********************************************************************/
Yes it works perfectly with endgaps7.txt test file.
Input: 
atattat
tattata
Edit distance = 4
a - 2
t t 0
a a 0
t t 0
t t 0
a a 0
t t 0
- a 2
Execution time = 0.001834 seconds

What happened: Insert a gap at the beginning of the Y string and the end of 
the X string and also the execution time is faster than what I expected 
i.e 0.001834 seconds 

/**********************************************************************
 * Look at your computer’s specs in the settings. 
 * How much RAM does your computer have and explain what this means? 
 **********************************************************************/
My computer has 16GB RAM and RAM typically stores the information your computer
is actively using so that it can be accessed quickly, thus the name "Random Access Memory".

/**********************************************************************
 *  For this question assume M=N. Look at your code and determine
 *  approximately how much memory it uses in bytes, as a function of 
 *  N. Give an answer of the form a * N^b for some constants a 
 *  and b, where b is an integer. Note chars are 2 bytes long, and 
 *  ints are 4 bytes long.
 *
 *  Provide a brief explanation.
 *
 *  What is the largest N that your program can handle if it is
 *  limited to 8GB (billion bytes) of memory?
 **********************************************************************/
a = 4
b = 2
largest N = 4360

Explanation :
As per the above condition M=N and if we take the following circumstances this would 
be the number of bytes used by the memory approximately.
4 * N^2 = 8GB = 8 * 1024 bytes * 1024 bytes * 1024 bytes
N = 46340

/**********************************************************************
 * Run valgrind if you can and attach the output file to your submission. 
 * If you cannot run it, explain why, and list all errors you’re seeing. 
 * If you can run it successfully, does the memory usage nearly match that 
 * found in the question above? 
 * Explain why or why not. 
/**********************************************************************
YES I was able to run valgrind. The output file massif.out.16131 is generated. 
	
    GB
2.981^                                                                       #
     |           @:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::#
     |           @                                                           #
     |          @@                                                           #
     |         :@@                                                           #
     |         @@@                                                           #
     |        :@@@                                                           #
     |        @@@@                                                           #
     |       :@@@@                                                           #
     |      :@@@@@                                                           #
     |      @@@@@@                                                           #
     |     :@@@@@@                                                           #
     |     :@@@@@@                                                           #
     |    ::@@@@@@                                                           #
     |   :::@@@@@@                                                           #
     |   :::@@@@@@                                                           #
     |  ::::@@@@@@                                                           #
     | :::::@@@@@@                                                           #
     | :::::@@@@@@                                                           #
     |::::::@@@@@@                                                           #
   0 +----------------------------------------------------------------------->Gi
     0                                                                   17.89

	file: ecoli28284.txt
	4*28484^2 / 1024^3 = 2.98017
	The theoretical value is very close to the actual value.
/**********************************************************************
 *  For each data file, fill in the edit distance computed by your
 *  program and the amount of time it takes to compute it.
 *
 *  If you get segmentation fault when allocating memory for the last
 *  two test cases (N=20000 and N=28284), note this, and skip filling
 *  out the last rows of the table.
 **********************************************************************/

data file           distance       time (seconds)     memory (MB)
------------------------------------------------------------------
ecoli2500.txt       118               0.056324         24.03
ecoli5000.txt       160               0.267532         95.64
ecoli7000.txt       194               0.440297         184.3
ecoli10000.txt      223               0.985002         384.9
ecoli20000.txt      3135              3.61543          1526.8
ecoli28284.txt      8394              7.22154          3052.5

/*************************************************************************
 *  Here are sample outputs from a run on a different machine for 
 *  comparison.
 ************************************************************************/

data file           distance       time (seconds)
-------------------------------------------------
ecoli2500.txt          118             0.171
ecoli5000.txt          160             0.529
ecoli7000.txt          194             0.990
ecoli10000.txt         223             1.972
ecoli20000.txt         3135            7.730

/**********************************************************************
 *  For this question assume M=N (which is true for the sample files 
 *  above). By applying the doubling method to the data points that you
 *  obtained, estimate the running time of your program in seconds as a 
 *  polynomial function a * N^b of N, where b is an integer.
 *  (If your data seems not to work, describe what went wrong and use 
 *  the sample data instead.)
 *
 *  Provide a brief justification/explanation of how you applied the
 *  doubling method.
 * 
 *  What is the largest N your program can handle if it is limited to 1
 *  day of computation? Assume you have as much main memory as you need.
 **********************************************************************/
a = 9e-9
b = 2
largest N = 3098386

Solution:
The largest N the program can handle from the calculations was : 
9e-9 * N ^ 2 = 24*60*60
N = 3098386
**********************************************************************
 *  Did you use the lambda expression in your assignment? If yes, where 
 * (describe a method or provide a lines numbers)
 **********************************************************************/
Yes I used lambda Expression in this assignment in EDistance.cpp file.
Code snippets of lambda function used.
int EDistance::penalty(char a, char b)
{
    return [](char a,char b){
    return a == b ? 0 : 1;
    }(a,b);
}
**********************************************************************
 *  List whatever help (if any) you received from the course TAs,
 *  instructor, classmates, or anyone else.
 **********************************************************************/
Irfan Mohammad - Tutor for Comp 4 

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
Implementing the logic to find the sequenece was itself hard and also
valgrind gave me some trouble while installing but had fun learning how 
it works.
/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
None 