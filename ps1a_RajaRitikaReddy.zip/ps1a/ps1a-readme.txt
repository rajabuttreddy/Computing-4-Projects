/**********************************************************************
 *  Linear Feedback Shift Register (part A) ps1a-readme.txt template
 **********************************************************************/

Name: Buttreddy Raja Ritika Reddy ( UML ID - 01987338 ) 
Hours to complete assignment:5 hours 
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.

 **********************************************************************/
Implementaion of linear fibonacci shift register is used in this program.
Understanding how to implement (LFSR) to generate pseudo random bits.


/**********************************************************************
 *  Explain the representation you used for the register bits 
 *  (how it works, and why you selected it)
 **********************************************************************/
I used arrays to represent register bits and the keyword "reg" is used in the
program.

/**********************************************************************
 * Discuss what's being tested in your two additional Boost unit tests
  **********************************************************************/
20bit in the first string and 18bit in the second one is being tested.


/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
I had some help with one of my classmates.


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
There were no serious problems as such, but I personally encountered some 
trouble implementing the LFSR, but figured it out eventaully.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
No comments 