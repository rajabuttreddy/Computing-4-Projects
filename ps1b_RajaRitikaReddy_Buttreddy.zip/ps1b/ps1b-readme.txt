/**********************************************************************
* Linear Feedback Shift Register (part B) ps1b-readme.txt template
**********************************************************************/
Name: Buttreddy Raja Ritika REDDY
Hours to complete assignment: 5
/**********************************************************************
* Briefly discuss the assignment itself and what you accomplished.
**********************************************************************/
This assignment is almost like the previous one. We Encode the image
using the xor operation and viceversa.
/**********************************************************************
* If you did any implementation for extra credit, describe it
* here and why it is interesting.
The additional feature is a password which is implemented by
Hash function which converts text to binary.
**********************************************************************/

/**********************************************************************
* List whatever help (if any) you received from the instructor,
* classmates, or anyone else.
My friend helped me with the additional feature.
**********************************************************************/
/**********************************************************************
* Describe any serious problems you encountered.
I had no such serious issues with the code.
**********************************************************************/
/**********************************************************************
* List any other comments here.
None
**********************************************************************/
